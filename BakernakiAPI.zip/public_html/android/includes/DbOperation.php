<?php

class DbOperation
{
    private $con;
    
    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        
        $db = new DbConnect();
        
        $this->con = $db->connect();
    }

    function getId($email)
    {
        $stmt = $this->con->prepare("SELECT id FROM user where email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($id);
        
        while($stmt->fetch()) {
            return $id;
        }
    }
    
    function login($email, $password)
    {
        $stmt = $this->con->prepare("SELECT id, type FROM user where email = ? and password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $stmt->bind_result($id, $type);
        
        while($stmt->fetch()) {
        	echo $id;
        	echo "?";
            echo $type;
        }
    }

	function userExist($email)
    {
        $stmt = $this->con->prepare("SELECT count(*) FROM user where email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($count);
        
        while($stmt->fetch()) {
            echo $count;
        }
    }    
    
    function getCategories()
    {
        $stmt = $this->con->prepare("SELECT * FROM categories where category_ID % 100 = 0");
        $stmt->execute();
        $stmt->bind_result($id, $name);
        
        while ($stmt->fetch()) {
            echo $id;
            echo "?";
            echo $name;
            echo "?";
        }
    }
    
    function getSubCategories($id)
    {
        $stmt = $this->con->prepare("SELECT * FROM categories where category_ID > ? && category_ID < ? + 100");
        $stmt->bind_param("ii", $id, $id);
        $stmt->execute();
        $stmt->bind_result($id, $name);
        
        while ($stmt->fetch()) {
            echo $id;
            echo "?";
            echo $name;
            echo "?";
        }
    }

    function getLevels()
    {
        $stmt = $this->con->prepare("SELECT * FROM degrees where degree_ID % 100 = 0");
        $stmt->execute();
        $stmt->bind_result($id, $name);
        
        while ($stmt->fetch()) {
            echo $id;
            echo "?";
            echo $name;
            echo "?";
        }
    }

    function getDegrees($id)
    {
        $id2 = $id + 100;

        $stmt = $this->con->prepare("SELECT * FROM degrees where degree_ID > ? && degree_ID < ?");
        $stmt->bind_param("ii", $id, $id2);
        $stmt->execute();
        $stmt->bind_result($id, $name);
        
        while ($stmt->fetch()) {
            echo $id;
            echo "?";
            echo $name;
            echo "?";
        }
    }

    function registerEmployee($type, $email, $password, $name, $sex, $address, $phone, $birthday, $degree, $year, $institution, $categories, $experience, $companies, $work, $interpersonal, $computer, $language, $achievements)
    {
    	$stmt = $this->con->prepare("INSERT INTO user(`email`, `password`, `type`) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $email, $password, $type);
        $stmt->execute();

        $id = $this->getId($email);

        $stmt = $this->con->prepare("INSERT INTO employee VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssis", $name, $birthday, $address, $phone, $id, $sex);
        $stmt->execute();

        $stmt = $this->con->prepare("INSERT INTO jobs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssiiisssss", $id, $categories, $work, $companies, $experience, $degree, $year, $institution, $interpersonal, $language, $computer, $achievements);
        $stmt->execute();
    }

    function registerEmployer($type, $email, $password, $name, $address, $phone, $details, $nature, $location, $salary, $description, $deadline, $degree, $categories, $experience)
    {
    	$stmt = $this->con->prepare("INSERT INTO user(`email`, `password`, `type`) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $email, $password, $type);
        $stmt->execute();

        $id = $this->getId($email);

        $stmt = $this->con->prepare("INSERT INTO circular(`category`, `min_deg`, `work_experience`, `deadline`, `job_description`, `job_nature`, `job_location`, `salary_range`, `ID`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisssssi", $categories, $degree, $experience, $deadline, $description, $nature, $location, $salary, $id);
        $stmt->execute();

        $stmt = $this->con->prepare("SELECT circular_ID FROM circular where id = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($cid);

        while ($stmt->fetch()) {
            $circular_ID = $cid;
        }


        $stmt = $this->con->prepare("INSERT INTO matches(`circular_ID`) VALUES (?)");
        $stmt->bind_param("i", $circular_ID);
        $stmt->execute();

        echo $circular_ID;

        $stmt = $this->con->prepare("INSERT INTO employer VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssis", $name, $address, $phone, $id, $details);
        $stmt->execute();
    }

    function getMatchedCirculars($id)
    {
        $id = "%_" . $id . "_%";

        $stmt = $this->con->prepare("SELECT circular_ID FROM matches where candidates like ?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->bind_result($cid);

        while ($stmt->fetch()) {
            echo $cid;
            echo "?";
        }
    }

    function getCircularData($circular_ID)
    {
        $stmt = $this->con->prepare("SELECT * FROM circular where circular_ID = ? LIMIT 1");
        $stmt->bind_param("i", $circular_ID);
        $stmt->execute();
        $stmt->bind_result($circular_ID, $category, $min_deg, $work_experience, $deadline, $job_description, $job_nature, $job_location, $salary_range, $ID);

        while ($stmt->fetch()) {
            echo $circular_ID;
            echo "?";
            echo $category;
            echo "?";
            echo $min_deg;
            echo "?";
            echo $work_experience;
            echo "?";
            echo $deadline;
            echo "?";
            echo $job_description;
            echo "?";
            echo $job_nature;
            echo "?";
            echo $job_location;
            echo "?";
            echo $salary_range;
            echo "?";
            echo $ID;
            echo "?";
        }
    }

    function getEmployerData($employer_ID)
    {
        $stmt = $this->con->prepare("SELECT * FROM employer where ID = ? LIMIT 1");
        $stmt->bind_param("i", $employer_ID);
        $stmt->execute();
        $stmt->bind_result($name, $address, $phone, $id, $details);

        while ($stmt->fetch()) {
            echo $name;
            echo "?";
            echo $address;
            echo "?";
            echo $phone;
            echo "?";
            echo $details;
            echo "?";
        }
    }

	function getCategoryName($category_ID)
    {
		$stmt = $this->con->prepare("SELECT category_name FROM categories where category_ID = ? - (? % 100) LIMIT 1");
        $stmt->bind_param("ii", $category_ID, $category_ID);
        $stmt->execute();
        $stmt->bind_result($name);

        while ($stmt->fetch()) {
            echo $name;
            echo " (";
        }    	

        $stmt = $this->con->prepare("SELECT category_name FROM categories where category_ID = ? LIMIT 1");
        $stmt->bind_param("i", $category_ID);
        $stmt->execute();
        $stmt->bind_result($name);

        while ($stmt->fetch()) {
            echo $name;
            echo ")";
        }
    }

    function getDegreeName($degree_ID)
    {
        $stmt = $this->con->prepare("SELECT degree_name FROM degrees where degree_ID = ? - (? % 100) LIMIT 1");
        $stmt->bind_param("ii", $degree_ID, $degree_ID);
        $stmt->execute();
        $stmt->bind_result($name);

        while ($stmt->fetch()) {
            echo $name;
            echo " (";
        }    	

        $stmt = $this->con->prepare("SELECT degree_name FROM degrees where degree_ID = ? LIMIT 1");
        $stmt->bind_param("i", $degree_ID);
        $stmt->execute();
        $stmt->bind_result($name);

        while ($stmt->fetch()) {
            echo $name;
            echo ")";
        }
    }

    function getEmployeeProfile($id)
    {
    	$stmt = $this->con->prepare("SELECT * FROM employee where ID = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($name, $birthday, $address, $phone, $id, $sex);

        while ($stmt->fetch()) {
            echo $name;
            echo "?";
            echo $birthday;
            echo "?";
            echo $address;
            echo "?";
            echo $phone;
            echo "?";
            echo $sex;
            echo "?";
        }
    }

    function getJobPreference($id)
    {
        $stmt = $this->con->prepare("SELECT * FROM jobs where ID = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($id, $categories, $details, $companies, $experience, $degree, $year, $institution, $interpersonal, $language, $computer, $achievements);

        while ($stmt->fetch()) {
            echo $categories;
            echo "?";
            echo $details;
            echo "?";
            echo $companies;
            echo "?";
            echo $experience;
            echo "?";
            echo $degree;
            echo "?";
            echo $year;
            echo "?";
            echo $institution;
            echo "?";
            echo $interpersonal;
            echo "?";
            echo $language;
            echo "?";
            echo $computer;
            echo "?";
            echo $achievements;
            echo "?";
        }
    }

    function getCirculars($id) {
    	$stmt = $this->con->prepare("SELECT circular_ID FROM circular where ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($id);

        while ($stmt->fetch()) {
            echo $id;
            echo "?";
        }
    }

    function getCandidates($circular_ID) {
    	$stmt = $this->con->prepare("SELECT interest_ID FROM matches where circular_ID = ?");
        $stmt->bind_param("i", $circular_ID);
        $stmt->execute();
        $stmt->bind_result($candidates);

        while ($stmt->fetch()) {
            echo $candidates;
        }
    }

    function editEmployerProfile($id, $name, $details, $address, $phone, $email, $password)
    {
        $stmt = $this->con->prepare("UPDATE user SET `email` = ?, `password` = ? WHERE ID = ?");
        $stmt->bind_param("ssi", $email, $password, $id);
        $stmt->execute();

        $stmt = $this->con->prepare("UPDATE employer SET `name` = ?, `address`= ?, `phone`= ?, `details` = ? WHERE ID = ?");
        $stmt->bind_param("ssssi", $name, $address, $phone, $details, $id);
        $stmt->execute();
    }

    function match($category1, $category2, $category3, $degree, $experience)
    {
    	$category1 = "%_" . $category1 . "_%";
    	$category2 = "%_" . $category2 . "_%";
    	$category3 = "%_" . $category3 . "_%";

    	$stmt = $this->con->prepare("SELECT ID FROM jobs WHERE (category like ? or category Like ? or category Like ?) and (degree >= ?) and (work_experience >= ?)");
    	$stmt->bind_param("sssii", $category1, $category2, $category3, $degree, $experience);
        $stmt->execute();
        $stmt->bind_result($candidate);

        while ($stmt->fetch()) {
            echo $candidate;
            echo "_";
        }
    }

    function setCandidates($circular_ID, $candidates)
    {
    	$stmt = $this->con->prepare("UPDATE matches SET candidates = ? WHERE circular_ID = ?");
        $stmt->bind_param("si", $candidates, $circular_ID);
        $stmt->execute();
    }

	function addCircular($id, $nature, $location, $salary, $description, $deadline, $degree, $categories, $experience)
    {
    	$stmt = $this->con->prepare("INSERT INTO circular(`category`, `min_deg`, `work_experience`, `deadline`, `job_description`, `job_nature`, `job_location`, `salary_range`, `ID`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisssssi", $categories, $degree, $experience, $deadline, $description, $nature, $location, $salary, $id);
        $stmt->execute();

        $stmt = $this->con->prepare("SELECT max(circular_ID) FROM circular WHERE ID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($circular_ID);

        $cid;

        while ($stmt->fetch()) {
            $cid = $circular_ID;
            echo $circular_ID;
        }

        $stmt = $this->con->prepare("INSERT INTO matches(`circular_ID`) VALUES (?)");
        $stmt->bind_param("i", $cid);
        $stmt->execute();
    }

    function deleteCircular($circular_ID)
    {
    	$stmt = $this->con->prepare("DELETE FROM matches WHERE circular_ID = ?");
        $stmt->bind_param("i", $circular_ID);
        $stmt->execute();

		$stmt = $this->con->prepare("DELETE FROM circular WHERE circular_ID = ?");
        $stmt->bind_param("i", $circular_ID);
        $stmt->execute();        
    }

    function addInterest($circular_ID, $id)
    {
    	$stmt = $this->con->prepare("UPDATE matches SET interest_ID = concat(interest_ID, ?, '_') WHERE circular_ID = ?");
    	$stmt->bind_param("ii", $id, $circular_ID);
        $stmt->execute();       
    }

    function removeInterest($circular_ID, $id)
    {
    	$id .= '_';
    	$stmt = $this->con->prepare("UPDATE matches SET interest_ID = replace(interest_ID, ?, '') WHERE circular_ID = ?");
        $stmt->bind_param("si", $id, $circular_ID);
        $stmt->execute();       
    }

    function saveEmployeeProfile($id, $address, $phone, $experience, $companies, $details, $interpersonal, $computer, $language, $achievements)
    {
        $stmt = $this->con->prepare("UPDATE employee SET address = ?, phone = ? WHERE ID = ?");
        $stmt->bind_param("ssi", $address, $phone, $id);
        $stmt->execute();

        $stmt = $this->con->prepare("UPDATE jobs SET work_details = ?, company_name = ?, work_experience = ?, skills_interpersonal = ?, skills_language = ?, skills_computer = ?, achievements = ? WHERE ID = ?");
        $stmt->bind_param("ssissssi", $details, $companies, $experience, $interpersonal, $language, $computer, $achievements, $id);
        $stmt->execute();        
    }

    function saveEmployerProfile($id, $address, $phone, $details)
    {
        $stmt = $this->con->prepare("UPDATE employer SET address = ?, phone = ?, details = ? WHERE ID = ?");
        $stmt->bind_param("sssi", $address, $phone, $details, $id);
        $stmt->execute();     
    }
}