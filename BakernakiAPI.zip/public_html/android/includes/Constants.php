<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'id3636036_bakernaki');
define('DB_PASS', 'bakernaki');
define('DB_NAME', 'id3636036_bakernaki');