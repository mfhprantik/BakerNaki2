<?php

require_once '../includes/DbOperation.php';

/*function isTheseParametersAvailable($params)
{
    $available     = true;
    $missingparams = "";
    
    foreach ($params as $param) {
        if (!isset($_POST[$param]) || strlen($_POST[$param]) <= 0) {
            $available     = false;
            $missingparams = $missingparams . ", " . $param;
        }
    }
    
    if (!$available) {
        echo 'Parameters ' . substr($missingparams, 1, strlen($missingparams)) . ' missing';
        die();
    }
}*/

if (isset($_GET['apicall'])) {
    
    switch ($_GET['apicall']) {
        
        case 'login':
            $db = new DbOperation();
            // isTheseParametersAvailable(array('email','password'));
            $db->login($_POST['email'], $_POST['password']);
            break;

        case 'userExist':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('email'));
            $db->userExist($_POST['email']);
            break;
        
        case 'getCategories';
            $db = new DbOperation();
            $db->getCategories();
            break;
        
        case 'getSubCategories';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getSubCategories($_POST['id']);
            break;

        case 'getLevels';
            $db = new DbOperation();
            $db->getLevels();
            break;
        
        case 'getDegrees';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getDegrees($_POST['id']);
            break;

        case 'registerEmployee';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('type', 'email', 'password', 'name', 'sex', 'address', 'phone', birthday', 'degree', 'year', 'institution', 'categories', 'experience', 'companies', 'work', 'interpersonal', 'computer', 'language', 'achievements'));
            $db->registerEmployee($_POST['type'], $_POST['email'], $_POST['password'], $_POST['name'], $_POST['sex'], $_POST['address'], $_POST['phone'], $_POST['birthday'], $_POST['degree'], $_POST['year'], $_POST['institution'], $_POST['categories'], $_POST['experience'], $_POST['companies'], $_POST['work'], $_POST['interpersonal'], $_POST['computer'], $_POST['language'], $_POST['achievements']);
            break;

        case 'registerEmployer';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('type', 'email', 'password', 'name', 'address', 'phone', 'details', nature', 'location', 'salary', 'description', 'deadline', 'degree', 'categories', 'experience'));
            $db->registerEmployer($_POST['type'], $_POST['email'], $_POST['password'], $_POST['name'], $_POST['address'], $_POST['phone'], $_POST['details'], $_POST['nature'], $_POST['location'], $_POST['salary'], $_POST['description'], $_POST['deadline'], $_POST['degree'], $_POST['categories'], $_POST['experience']);
            break;

        case 'getMatchedCirculars';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getMatchedCirculars($_POST['id']);
            break;

        case 'getCircularData';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID'));
            $db->getCircularData($_POST['circular_ID']);
            break;

        case 'getEmployerData';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('employer_ID'));
            $db->getEmployerData($_POST['employer_ID']);
            break;

        case 'getCategoryName';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('category_ID'));
            $db->getCategoryName($_POST['category_ID']);
            break;

        case 'getDegreeName';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('degree_ID'));
            $db->getDegreeName($_POST['degree_ID']);
            break;

        case 'getEmployeeProfile';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getEmployeeProfile($_POST['id']);
            break;

        case 'getJobPreference';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getJobPreference($_POST['id']);
            break;

        case 'getCirculars';
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id'));
            $db->getCirculars($_POST['id']);
            break;

        case 'getCandidates':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID'));
            $db->getCandidates($_POST['circular_ID']);
        	break;

        case 'editEmployerProfile':
            
            $db = new DbOperation();
            // isTheseParametersAvailable(array('id', name', 'email', 'address', 'phone', 'password', 'detaile'));
            $db->editEmployerProfile($_POST['id'], $_POST['name'], $_POST['details'], $_POST['address'], $_POST['phone'], $_POST['email'], $_POST['password']);
            break;

        case 'match':
            $db = new DbOperation();
            // isTheseParametersAvailable(array('category1', 'category2', 'category3', 'degree', 'expeerience'));
            $db->match($_POST['category1'], $_POST['category2'], $_POST['category3'], $_POST['degree'], $_POST['experience']);
            break;

        case 'setCandidates':
            $db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID', 'candidates'));
            $db->setCandidates($_POST['circular_ID'], $_POST['candidates']);
            break;

        case 'addCircular':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('id', 'nature', 'location', 'salary', 'description', 'deadline', 'degree', 'categories', 'experience'));
            $db->addCircular($_POST['id'], $_POST['nature'], $_POST['location'], $_POST['salary'], $_POST['description'], $_POST['deadline'], $_POST['degree'], $_POST['categories'], $_POST['experience']);
        	break;

        case 'deleteCircular':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID'));
            $db->deleteCircular($_POST['circular_ID']);
            break;

        case 'addInterest':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID', 'id'));
            $db->addInterest($_POST['circular_ID'], $_POST['id']);
            break;

        case 'removeInterest':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('circular_ID', 'id'));
            $db->removeInterest($_POST['circular_ID'], $_POST['id']);
            break;

        case 'saveEmployeeProfile':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('id', 'address', 'phone', 'experience', 'companies', 'details', 'interpersonal', 'computer', 'language', 'achievements'));
            $db->saveEmployeeProfile($_POST['id'], $_POST['address'], $_POST['phone'], $_POST['experience'], $_POST['companies'], $_POST['details'], $_POST['interpersonal'], $_POST['computer'], $_POST['language'], $_POST['achievements']);
            break;

        case 'saveEmployerProfile':
        	$db = new DbOperation();
            // isTheseParametersAvailable(array('id', 'address', 'phone', 'details'));
            $db->saveEmployerProfile($_POST['id'], $_POST['address'], $_POST['phone'], $_POST['details']);
            break;
    }
} else {
    echo "Invalid API Call";
}